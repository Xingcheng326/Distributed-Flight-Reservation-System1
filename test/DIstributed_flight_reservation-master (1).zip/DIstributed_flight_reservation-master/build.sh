mkdir bin



# copy python files from src to bin
cp server.py bin/
cp reservation.py bin/


cp run.sh bin/

echo Done!

exit 0