python3 server.py alpha

exit 0